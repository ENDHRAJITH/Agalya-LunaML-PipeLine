
# Luna AI Builder - RandomForest Model
## Task: classification
## Dataset: Iris Flowers
## Generated: 20260322_134335

## Performance Metrics
- Accuracy: 90.00%
- Macro F1: 0.8997

## Files
- `model.pkl`     - Trained scikit-learn pipeline (scaler + model)
- `predict.py`    - Ready-to-use inference script
- `metadata.json` - Model info and metrics
- `README.md`     - This file

## Quick Start
```bash
pip install scikit-learn joblib numpy
python predict.py
```

## Load in your code
```python
import joblib
import numpy as np

model = joblib.load("model.pkl")
X = np.array([your_features]).reshape(1, -1)
prediction = model.predict(X)
print(prediction)
```

## Feature Names
  1. sepal length (cm)
  2. sepal width (cm)
  3. petal length (cm)
  4. petal width (cm)
