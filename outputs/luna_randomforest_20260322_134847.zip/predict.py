
# Luna AI Builder - Generated Inference Code
# Task: regression
# Model: RandomForest
# Dataset: Diabetes Progression
# Generated: 20260322_134847

import joblib
import numpy as np

# Load model
model = joblib.load("model.pkl")

# ── Predict function ──────────────────────────────────────────────
def predict(features: list):
    """
    features: list of 10 numeric values
    Feature order: ['age', 'sex', 'bmi', 'bp', 's1', 's2', 's3', 's4', 's5', 's6']
    """
    X = np.array(features).reshape(1, -1)
    prediction = model.predict(X)
    return prediction[0]

# ── Example usage ─────────────────────────────────────────────────
if __name__ == "__main__":
    # Replace with your actual feature values
    sample = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    result = predict(sample)
    print(f"Prediction: {result}")
