
# Luna AI Builder - RandomForest Model
## Task: regression
## Dataset: Diabetes Progression
## Generated: 20260322_134847

## Performance Metrics
- R² Score: 0.4415
- RMSE: 54.3984
- MAE:  44.1712

## Files
- `model.pkl`     - Trained scikit-learn pipeline (scaler + model)
- `predict.py`    - Ready-to-use inference script
- `metadata.json` - Model info and metrics
- `README.md`     - This file

## Quick Start
```bash
pip install scikit-learn joblib numpy
python predict.py
```

## Load in your code
```python
import joblib
import numpy as np

model = joblib.load("model.pkl")
X = np.array([your_features]).reshape(1, -1)
prediction = model.predict(X)
print(prediction)
```

## Feature Names
  1. age
  2. sex
  3. bmi
  4. bp
  5. s1
  6. s2
  7. s3
  8. s4
  9. s5
  10. s6
