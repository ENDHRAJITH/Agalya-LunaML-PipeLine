
# Luna AI Builder - GradientBoosting Model
## Task: regression
## Dataset: California Housing
## Generated: 20260322_134340

## Performance Metrics
- R² Score: 0.7756
- RMSE: 0.5422
- MAE:  0.3717

## Files
- `model.pkl`     - Trained scikit-learn pipeline (scaler + model)
- `predict.py`    - Ready-to-use inference script
- `metadata.json` - Model info and metrics
- `README.md`     - This file

## Quick Start
```bash
pip install scikit-learn joblib numpy
python predict.py
```

## Load in your code
```python
import joblib
import numpy as np

model = joblib.load("model.pkl")
X = np.array([your_features]).reshape(1, -1)
prediction = model.predict(X)
print(prediction)
```

## Feature Names
  1. MedInc
  2. HouseAge
  3. AveRooms
  4. AveBedrms
  5. Population
  6. AveOccup
  7. Latitude
  8. Longitude
