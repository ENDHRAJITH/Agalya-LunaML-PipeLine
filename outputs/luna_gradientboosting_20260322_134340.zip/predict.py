
# Luna AI Builder - Generated Inference Code
# Task: regression
# Model: GradientBoosting
# Dataset: California Housing
# Generated: 20260322_134340

import joblib
import numpy as np

# Load model
model = joblib.load("model.pkl")

# ── Predict function ──────────────────────────────────────────────
def predict(features: list):
    """
    features: list of 8 numeric values
    Feature order: ['MedInc', 'HouseAge', 'AveRooms', 'AveBedrms', 'Population', 'AveOccup', 'Latitude', 'Longitude']
    """
    X = np.array(features).reshape(1, -1)
    prediction = model.predict(X)
    return prediction[0]

# ── Example usage ─────────────────────────────────────────────────
if __name__ == "__main__":
    # Replace with your actual feature values
    sample = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
    result = predict(sample)
    print(f"Prediction: {result}")
