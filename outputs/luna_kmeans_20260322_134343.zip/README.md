
# Luna AI Builder - KMeans Model
## Task: clustering
## Dataset: Synthetic Clustering (4 groups)
## Generated: 20260322_134343

## Performance Metrics
- Clusters: 4
- Silhouette Score: 0.8042

## Files
- `model.pkl`     - Trained scikit-learn pipeline (scaler + model)
- `predict.py`    - Ready-to-use inference script
- `metadata.json` - Model info and metrics
- `README.md`     - This file

## Quick Start
```bash
pip install scikit-learn joblib numpy
python predict.py
```

## Load in your code
```python
import joblib
import numpy as np

model = joblib.load("model.pkl")
X = np.array([your_features]).reshape(1, -1)
prediction = model.predict(X)
print(prediction)
```

## Feature Names
  1. feature_0
  2. feature_1
  3. feature_2
  4. feature_3
